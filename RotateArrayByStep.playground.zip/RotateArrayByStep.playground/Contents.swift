import UIKit

var nums = [1,2,3,4,5,6,7]

//var array = [1,2,3,4,5,6,7]
//let k = 5
//let length = array.count
//let reversed: Array = array.reversed()
//let leftPart: Array = reversed[0..<k].reversed()
//let rightPart: Array = reversed[k..<length].reversed()
//array = leftPart + rightPart
//
func rotate(_ nums: inout [Int], _ k: Int) {
    let lenghtNums = nums.count
    if (k >= 1 && k <= 105) && (lenghtNums >= 1 && lenghtNums <= 105) {
            for _ in 1...k {
                let lastItem = nums.removeLast()
                nums.insert(lastItem, at: 0)
            }
        print(nums)
    } else {
        print("The range of k must been 1-105 your k = \(k) \nThe lenght of array must been 1-105 your lenght array = \(lenghtNums)")
    }

}

rotate(&nums, 110)

func rotate2(_ nums: inout [Int], _ k: Int) {
    let length = nums.count
    let reversed: Array = nums.reversed()
    let leftPart: Array = reversed[0..<k].reversed()
    let rightPart: Array = reversed[k..<length].reversed()
    nums = leftPart + rightPart

}

rotate2(&nums, 1)

//func rotate3(_ nums: inout [Int], _ k: Int) {
//    let lenghtNums = nums.count
//    var revers: Array = nums.reversed()
//    var firstArray: Array = nums.remove(at: k - 1)
//    var secondArray: Array = revers.remove(at: k - lenghtNums)
//    nums = secondArray + firstArray
//}

//rotate3(&nums, 1)



